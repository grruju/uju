sap.ui.define([
	"sapbtp/usetemplate/test/unit/controller/App.controller"
], function () {
	"use strict";
});
