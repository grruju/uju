sap.ui.define([
	"syncc203/salesorderchart/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
