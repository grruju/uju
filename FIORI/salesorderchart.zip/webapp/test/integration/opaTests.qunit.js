/* global QUnit */

sap.ui.require(["sync/c203/salesorderchart/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
