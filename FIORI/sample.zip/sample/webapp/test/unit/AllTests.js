sap.ui.define([
	"sapsync/sample/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
