/* global QUnit */

sap.ui.require(["sap/sync/sample/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
